# HuGo v6 PWA — Installation Guide
## Human Rights on the Go
### Bulacan Police Provincial Human Rights Affairs Office · BULPPO, PRO 3

---

## WHAT'S NEW IN v6

### Universal Data Access Control (ALL modules)
- Station users can ONLY access their own station's data across ALL modules
- Automatic blocking of cross-station data access — no exceptions
- Access denial message shown with full audit log entry
- Every data access attempt is logged (user ID, role, station, timestamp, granted/denied)
- Audit log is visible to super users only in the Master report tab
- Data isolation is per station (not per district)

### All v5 features included:
- Station login: select station + enter passcode
- Super user login: master password
- Weekly PICE: Nr of Participants field
- Weekly PICE consolidated report: exact BULPPO format with action photos
- PHROs & COs: submission notification dashboard
- IDD: notification dashboard with priority flags and urgent counts
- Camera: activates immediately after token validation

---

## LOGIN CREDENTIALS (for testing)

### Station users
- Select your station from the dropdown
- All station passcodes (demo): **PHRA2025**

### Super user
- Master password: **HUGO@ADMIN2025**

### Camera inspection tokens
- HUGO-INSPECT-01
- PHRA-CAM-2025
- BULPPO-SU-99

---

## DEPLOY TO GITHUB PAGES

Your GitHub: https://github.com/Dilcue16

1. Go to: https://github.com/new
2. Repository name: hugo-pwa
3. Set to Public → Create repository
4. Upload ALL files from this package (keep folder structure)
5. Settings → Pages → Deploy from main branch → Save
6. Your URL: https://dilcue16.github.io/hugo-pwa/

## INSTALL ON ANDROID

1. Open Chrome → go to your GitHub Pages URL
2. Tap ⋮ menu → "Add to Home screen"
3. Tap "Add"
4. HuGo launches fullscreen like a native app!

## INSTALL ON iPHONE

1. Open Safari → go to your URL
2. Tap Share button → "Add to Home Screen"
3. Tap "Add"

---

## ACCESS CONTROL RULES (v6)

| Role | Own Station Data | Other Station Data | Master Report | Audit Log |
|------|-----------------|-------------------|---------------|-----------|
| Station user | ✅ Full access | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| Super user | ✅ Full access | ✅ Full access | ✅ Full access | ✅ Full access |

Access denial is automatic and logged.
Data isolation is per station — not per district.
